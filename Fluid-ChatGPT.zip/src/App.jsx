import React, { useState, useEffect } from "react";
import "./App.css";
import { Configuration, OpenAIApi } from "openai";
import axios from "axios";
import { MdRecordVoiceOver, MdVoiceOverOff } from "react-icons/md";
import { ClockLoader } from "react-spinners";
const configuration = new Configuration({
  apiKey: "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",
});
const openai = new OpenAIApi(configuration);

// const heygenApiKey = "MDRhMGEwZjJhODUwNDRlZWE5NGQ2MmMxNTZmZTU4ZTMtMTY4OTAzMzQzNQ==";
const heygenApiKey = "";

const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition;
const mic = new SpeechRecognition();
mic.continuous = true;
mic.interimResults = true;
mic.lang = "en-US";

function App() {
  const [message, setMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [note, setNote] = useState('');
  const [chats, setChats] = useState([
    {
      role: "system",
      content: "You are a ChatGPT. Answer in 50 words",
    },
  ]);
  const [videoURL, setVideoURL] = useState("");
  const [processing, setProcessing] = useState(false);

  const retrieveVideo = async (videoId) => {
    // eslint-disable-next-line no-constant-condition
    while (true) {
      try {
        const response = await axios({
          method: "get",
          url: `https://api.heygen.com/v1/video_status.get?video_id=${videoId}`,
          headers: {
            accept: "application/json",
            "x-api-key": heygenApiKey,
          },
        });

        const status = response.data.data.status;
        if (status == "completed") {
          return response.data.data.video_url;
        }
      } catch (err) {
        console.log(err);
      }
      // Add here sleep for 5 seconds
      await new Promise((r) => setTimeout(r, 5000));
    }
  };

  const generateVideo = async (text) => {
    const url = "https://api.heygen.com/v1/video.generate";
    const data = {
      background: "#ffffff",
      clips: [
        {
          avatar_id: "Daisy-inskirt-20220818",
          avatar_style: "normal",
          input_text: text,
          offset: {
            x: 0,
            y: 0,
          },
          scale: 1,
          voice_id: "1bd001e7e50f421d891986aad5158bc8",
        },
      ],
      ratio: "16:9",
      test: true,
      version: "v1alpha",
    };

    const headers = {
      "X-Api-Key": heygenApiKey,
      "Content-Type": "application/json",
    };

    axios
      .post(url, data, { headers })
      .then(async (response) => {
        const video_url = await retrieveVideo(response.data.data.video_id);
        setVideoURL(video_url);
      })
      .catch((error) => {
        console.error("Error:", error.response.data);
      });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (message.length <= 0) return;

    setProcessing(true);

    let newChats = [...chats, { role: "user", content: message }];
    setMessage("");

    openai
      .createChatCompletion({
        model: "gpt-3.5-turbo",
        messages: newChats,
      })
      .then(async (res) => {
        const response_msg = res.data.choices[0].message;
        newChats = [...newChats, response_msg];

        setChats(newChats);

        await generateVideo(response_msg.content);

        setProcessing(false);
      })
      .catch((error) => {
        console.log(error);
        setProcessing(false);
      });
  };

  useEffect(() => {
    mic.onstart = () => {
      console.log('Mics on');
    };

    mic.onresult = (event) => {
      const transcript = Array.from(event.results)
        .map((result) => result[0])
        .map((result) => result.transcript)
        .join('');
      console.log(transcript);
      setNote(transcript);
    };

    mic.onerror = (event) => {
      console.log(event.error);
    };
  }, []);

  const handleVoiceClick = () => {
    if (!isRecording) {
      mic.start();
      setIsRecording(true);
    } else {
      mic.stop();
      setIsRecording(false);
    }
  };

  return (
    <div className="app">
      <div className="main_container" style={{ zIndex: 9999 }}>
        <div>
          <div className="loading_container">
            <div className="video-container">
              <div className="loading_box">
                {processing ? (
                  <ClockLoader color="#36d7b7" size={150} />
                ) : videoURL ? (
                  <video controls src={videoURL}></video>
                ) : (
                  "Chat AI"
                )}
              </div>
            </div>
          </div>
          <div>
            <div>
              <form onSubmit={handleSubmit}>
                <input
                  type="text"
                  name="message"
                  className="message_input"
                  autoComplete="off"
                  value={message}
                  placeholder="Type a message here and hit Enter..."
                  onChange={(e) => setMessage(e.target.value)}
                />
                <button
                  className="voice_button"
                  type="button"
                  onClick={handleVoiceClick}
                >
                  {isRecording ? <MdVoiceOverOff /> : <MdRecordVoiceOver />}
                </button>
                <div>{note}</div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
